//bank account tracking program  
// tells you your account number
public abstract class BankAccount
	{       
        private double balance = 0.0;
        private String accountNumber = "0001";
        private Customer accountHolder;
        

        
        BankAccount(){}
        BankAccount(double balance){this.balance=balance;}
        BankAccount(Customer accountholder){this.accountHolder=accountholder;}
        BankAccount(Customer accountholder, double balance)
            {this.accountHolder=accountholder; this.balance=balance;}
        BankAccount(double balance, String accountNumber)
            {this.balance= balance; this.accountNumber= accountNumber;}
        BankAccount(double balance, String accountNumber, Customer accountholder) 
            {this.balance=balance;
            this.accountNumber= accountNumber; this.accountHolder = accountholder;}
        
        public BankAccount(BankAccount c) {this.balance = c.balance; this.accountHolder = c.accountHolder;}
        


        protected abstract double getMonthlyFeesAndInterest();
        
        
        public void monthEndUpdate() {
             double balance2 = getMonthlyFeesAndInterest();
             balance = getBalance() + balance2;
        }
             
        
        public double getBalance()
            {   
                System.out.println(balance); 
                return balance;
            }

        public void setBalance(double a){
            this.balance = a;
        }
            
            public String getAccountNumber()
            {   
                System.out.println(accountNumber);
                return accountNumber;
            }
            
            
            public String toString()
            {   

    //                String balance_string = Double.toString(balance);
      //          
        //        String account_balance = ( " " + accountNumber+ ": " + balance);
          //      System.out.println(accountNumber + balance);
                return "("+ this.accountHolder+")" + " "+ accountNumber +":" + " " + balance;
            }
            public void deposit(double hi)
            {
                if (hi > 0)
                {
                    balance = balance + hi;
                }
            }
            public void withdraw(double bye) 
            {
                if ((bye > 0) && (bye <= balance))
                {
                balance -= bye;
                }

            }

            public void setAccountHolder(Customer b)
            {
        
               accountHolder = b; 
            }
            
            public Customer getAccountHolder()
            {
                return accountHolder;
            }
            
            public void transfer(double a, BankAccount b)
            {
                if (a <= this.balance)
                {
                    this.balance -= a;
                    b.deposit(a);
                    
                }
            }
            
      
            
           
            
                
            
    }

    


            


