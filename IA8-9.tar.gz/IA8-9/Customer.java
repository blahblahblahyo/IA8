//customer class
import java.io.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.File;
import java.util.Scanner;

class Customer
{

        private String name;
        private int customerID;

        //changed default constructor if doesn't work

        Customer() {name = "joe"; customerID = 0;}

        Customer(BufferedReader read) throws IOException  {
            //String filename = "name.txt";
            //read = new BufferedReader(filename);
            try {
                
            
            
            String line = read.readLine();
            int num = read.read();
            if(read.readLine() == null) {
                throw IOException;
            }
            if(line != null) {
                this.name = line;
                this.customerID = num;
            }
            else
            { this.name = read.readLine(); }
            read.close(); 
        }
        catch(IOException) {
            System.out.print("Customer is null in file");
        }
        }
        
        
        Customer(String name){this.name=name;}
        Customer(String name, int customerID){this.name=name; this.customerID=customerID;}
        
        public Customer(Customer c) {this(c.getName(), c.getID());} 

        public void save(PrintWriter var) throws IOException {
            var.write(this.name); 
            var.write("\n" + this.customerID);
            var.close();
        }

        public String getName()
        {
                return name;
        }

        public String setName(String newname)
        {
                this.name = newname;
                return name;
        }

        public int getID()
        {
                return customerID;
        }
        
        public int setId(int customerId)
        {
                return customerID;
        }

        public String toString()
        {
                System.out.println("customer: " + name + " customerId: " + customerID);
                String nicestring = (name +" " + customerID);
                return nicestring;
        } 

}
